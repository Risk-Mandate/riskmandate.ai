# GRANT — everything the agent can do

> Measured from the deployment shape, not from your account and not by you. Every row says how it is known, what stands in the way, and whether it can be undone. Irreversible rows first.

**Vault** `google-workspace-mcp` · **status** template · **shape** `google/workspace-mcp/default` · **grant** 2026-09-15 · **mandate** 2026-09-15 · **vocabulary** abp.sgit.ai v0.3.0 · **as at** 2026-09-15

---


**Shape** The Google Workspace MCP servers (Gmail, Drive, Docs, Sheets, Slides, Calendar, Chat) (Google) · **surface** mcp · **grant version** 2026-09-15 · **rows** 6, of which **0 measured** and 6 derived · **widest reach** world

## What the words mean here

Google's own MCP servers, one per Workspace product, used from an MCP client such as an IDE or an agent. Each server "inherits the same permissions and data governance controls as the user": it acts as the person who consented, over everything that person can reach. The rows below are the OAuth scopes the setup page tells you to add to the project, read as capabilities; the client that holds the token has a grant of its own, which is a separate shape.

| Reach | In this shape means |
| --- | --- |
| host | the Google account's Drive and mailbox — every file owned by or shared to the user; not your machine |
| tenant | the Google account the consent was given for, and the Workspace domain it belongs to |
| world | anyone reachable by mail from that account |

## The rows

| Capability | What it is | Barrier | Undo | Evidence | Via | What stands in the way | Whose material |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `read.message.tenant` | Read mail or chat it is connected to | ○ boundary | no | documented | gmail.readonly | the OAuth scope, consented on Google's screen; a Workspace administrator can restrict third-party access to the domain | mixed |
| `send.message.world` | Send a message to anyone | ○ boundary | no | documented | gmail.compose | the OAuth scope | third_party |
| `read.file.host` | Read any file the account can reach | ○ boundary | no | documented | drive.readonly | the OAuth scope — a restricted scope in Google's own classification | mixed |
| `authenticate-as.credential.tenant` | Act in accounts with the credentials it holds | ○ boundary | no | documented | the OAuth consent | Google's consent screen and the project's scope list; the token is held by the MCP client | own |
| `read.credential.host` | Read credentials stored where it runs | ● none | no | inferred | gmail.readonly, drive.readonly | — | own |
| `write.file.host` | Change any file the account can reach | ○ boundary | with-effort | documented | drive.file, documents, spreadsheets, presentations | the OAuth scopes | mixed |

**Whose material** is not in the published grammar. It is the property Lab 01 found a connector shape needs — `own`, `organisation`, `third_party` or `mixed` — and is asked of the model site as Lab 03 request 1. `mixed` is the finding: no setting any of these vendors offers makes it `own`.

## The notes behind the rows

- **`read.message.tenant`** — gmail.readonly — "View your email messages and settings." Every message and the settings. No Gmail scope filters by sender, label or date; the only narrower one, gmail.metadata, cannot return a body.
- **`send.message.world`** — gmail.compose — "Manage drafts and send emails." The setup page advertises "create draft emails"; the scope it asks for also sends. Whether the server exposes a tool that sends is open, below.
- **`read.file.host`** — drive.readonly — "View and download all your Drive files." A Drive listing's default corpus is "files owned by or shared to the user": everything any colleague, client or counterparty ever shared.
- **`authenticate-as.credential.tenant`** — every server acts as the user who consented — "inherit the same permissions and data governance controls as the user"
- **`read.credential.host`** — a mailbox carries password resets, one-time codes and invitations; a drive carries exported keys and configuration. Reading all of either reads those too, and no scope separates them. Inferred from the two read rows, not documented.
- **`write.file.host`** — drive.file creates new files or modifies files the user opened with the app; the Docs, Sheets and Slides servers each ask for the full write scope for their document type beside the read-only one. What "full" includes is open, below.

## Permitted, and blocked

The grant above is what the agent can do **after** the blocks. This is what something withholds. A block is not a property of the credential: some of these are the credential's own ceiling, and some are a vendor choosing not to ship a tool the credential would authorise. Each one names what blocks it, because those two are not the same object and a reader who is shown them under one heading has been told something this document cannot support.

| What | Blocked by | Who holds the block | Why | Source |
| --- | --- | --- | --- | --- |
| your machine's files | the hosting — the servers are Google's, and what the MCP client itself reaches is a separate shape | _not yet recorded_ | the servers are hosted by Google; what the MCP client itself can reach is that client's own grant, a separate shape | https://developers.google.com/workspace/guides/configure-mcp-servers |
| permanent deletion of mail | Google's scope ceiling — only https://mail.google.com/ permits it, and it is not on the list | _not yet recorded_ | only the https://mail.google.com/ scope permits it ("Read, compose, send, and permanently delete all your email"), and it is not on the list | https://developers.google.com/workspace/gmail/api/auth/scopes |
| labelling or unlabelling mail | the scopes on the list — gmail.labels exists and was not requested | _not yet recorded_ | gmail.labels ("See and edit your email labels") exists and is not on the list | https://developers.google.com/workspace/gmail/api/auth/scopes |
| creating or changing calendar events | the three Calendar scopes requested, all of them read-only | _not yet recorded_ | the three Calendar scopes requested are calendarlist.readonly, events.readonly and events.freebusy; "schedule meetings" is advertised on the same page | https://developers.google.com/workspace/guides/configure-mcp-servers |

## Where the vendor's own pages disagree

Advertised in one place, permitted in another, and the two do not match. Published unresolved on purpose: settling any of these by connecting an assistant and trying would mean probing somebody else's system, which is out of bounds here. If the vendor says which page is right, this table changes and says so.

| What is advertised | What the grant permits | State |
| --- | --- | --- |
| Take action: "schedule meetings" | calendar.calendarlist.readonly, calendar.events.readonly, calendar.events.freebusy — all read-only | **unresolved** |
| Take action: "create draft emails" | gmail.compose — "Manage drafts and send emails": sending as well as drafting | **unresolved** |
| Read data: "retrieve files" | drive.readonly over the user corpus; whether shared drives are in the search (includeItemsFromAllDrives) is not stated | **undocumented** |

Sources: <https://developers.google.com/workspace/guides/configure-mcp-servers> · <https://developers.google.com/workspace/gmail/api/auth/scopes> · <https://developers.google.com/workspace/drive/api/reference/rest/v3/files/list>

## Open questions

**4** things this grant cannot settle from the pages it was read from. Each is in `RESEARCH-NEEDED.md` with how to settle it, and can be handed to a separate agent. Until it is answered, the row it belongs to stands at the evidence tier shown.

## The four barriers, and the test

| | Barrier | What stands in the way | Is it a control |
| --- | --- | --- | --- |
| ● | none | nothing in the way | no |
| ◉ | expectation | a rule in prose, enforced by nobody | no |
| ◐ | setting | a switch the agent's own account can flip | no |
| ○ | boundary | enforced above the grant, out of the agent's reach | **yes** |

> A control bounds a grant only if it is enforced by something the grant does not include.

A setting the agent's own account can change is not a control, because the grant includes the ability to remove the bound. A boundary enforced above it is one, because it does not.

## Evidence tiers

| Tier | Means |
| --- | --- |
| derived | from what the thing architecturally is; a claim until somebody runs the probes |
| inferred | from another row or another profile, by reasoning rather than by observation |
| self-reported | reported by the operator, the harness or the tool itself, without an independent probe |
| documented | the vendor, or a published tool, says so |
| measured ✓ | a probe run on an instance, dated, with an evidence file |
| observed ✓ | seen directly, on the thing itself, by the thing itself |

✓ marks the tiers this vault counts as measured. Nothing here was obtained by probing anybody else's system: a row is measured only from a system we are entitled to run, or from the vendor's own published documentation.

## Ask the agent to check it

The agent is running in the deployment this file describes, so it can look. What it reports is a claim until a log held outside it agrees — but a claim from inside the deployment is a better starting point than a template. Paste this into a session running in the shape above:

```
You are running inside the deployment described in GRANT.md. Compare each row with what you
can actually reach from here, and report — do not change any file except the one named below.

For every row: PRESENT, ABSENT or CANNOT TELL; which tool reaches it; one line of evidence
(a command's output, a tool's own description, a documentation sentence with its URL).
Never exercise a capability whose undo class is "no" to prove it exists: presence of a
credential file is evidence; using it is not permitted.
Add a row for anything you can reach that is not listed, in verb.object.reach form, using
only the 23 primitives in data/vocabulary/capabilities.json. A new path, host or mailbox is
an instance of an existing primitive, not a new one.
Do not touch MANDATE.md or data/mandate.json — that file is the deployer's, not yours.
Write the result to history/grant-check--<today>.md with the date and the tool versions
you can see. Everything in it is self-report; say so at the top.
```

---

_This describes the deployment shape as at this date. If the risk changed, the deployment changed — not this document._ 
No score, rating, level or traffic light appears in this vault or in its data, and none will. The behaviour policy describes; it does not judge. 
Generated by `scripts/site/build-abp-vault.mjs` from `data/grant.json`, `data/mandate.json` and the pinned vocabulary; `data/mandate.json` is the only file a person writes. Licence: the published template is CC BY 4.0; a paid copy carries a commercial licence to the buyer. See LICENCE.md.

