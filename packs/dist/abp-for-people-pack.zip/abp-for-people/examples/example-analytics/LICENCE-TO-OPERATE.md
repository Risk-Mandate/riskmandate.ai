# LICENCE TO OPERATE — the organisation authorises the agent, under this behaviour policy, for an interval

> The organisation is the authority, the behaviour policy is the instrument, and the agent is the licensee. Self-issued, witnessed, and dated — which is how most assurance works.

**Vault** `example-analytics` · **status** draft · **shape** `anthropic/gmail-connector/default` · **grant** 2026-09-16 · **mandate** 2026-09-24 · **vocabulary** abp.sgit.ai v0.3.0 · **as at** 2026-09-24

---


| | |
| --- | --- |
| **Licensee** | Claude, with the Gmail connector enabled and nothing else — Calendar and Drive are separate toggles and left off in this shape — deployment shape `anthropic/gmail-connector/default`, grant version 2026-09-16 |
| **Authority** | Example Analytics |
| **Accountable owner** |  |
| **Instrument** | This behaviour policy: mandate `find-and-draft-for-client-work` (2026-09-24), delta `anthropic__gmail-connector__default__find-and-draft-for-client-work` (2026-09-24T20:57:15Z), vocabulary abp.sgit.ai v0.3.0 |
| **Issued** | — |
| **Valid until** | — an interval is set when it is issued; a licence with no expiry is not a decision — |

## Scope — what the licensee is authorised to do (1)

- `read.message.tenant` — Read mail or chat it is connected to

## Conditions — what the licensee is asked not to do, and what enforces each (5)

A condition is only as good as the thing in its last column. Conditions with ● or ◉ beside them are asked, not enforced; the organisation issuing this licence is accepting that, for the interval above, with its eyes open.

| Condition | Asked because | Barrier | Enforced by | Who holds that |
| --- | --- | --- | --- | --- |
| Do not `send.message.world` (send a message to anyone) | the mandate refuses it | ◐ setting | two layers. At consent, Google's screen asks for "Manage drafts and send emails." (gmail.compose) and "Read, compose and send emails from your Gmail account." (gmail.modify), each with its own tick box, all pre-ticked under "Select all" — unticked, sending would be a boundary; this shape assumes the default. After consent, the per-action approval prompt: "By default, Claude asks for your approval before each of these actions. On Team and Enterprise plans, owners decide whether members can allow these actions to run without asking each time." A switch the account, or an org owner, can flip. On the screen the prompt reads "Claude wants to use Send email message from Gmail" with three buttons: Deny · Always allow · Allow once. "Always allow" is the switch — one click by the account holder, and the prompt is gone for good. | you — moves without you: **yes** |
| Do not `authenticate-as.credential.tenant` (act in accounts with the credentials it holds) | the mandate never authorised it | ○ boundary | the Google OAuth consent; "You must authenticate directly with your Google account before using these connectors." Revocable from the Google account ("To make changes at any time, go to your Google Account.") and from Claude's Connectors settings. | a vendor, against a consent you gave — moves without you: **with-your-consent** |
| Do not `read.credential.host` (read credentials stored where it runs) | the mandate refuses it | ● none | **nothing** — a line in prose | — |
| Do not `read.record.history` (read a retained record: shell history, past sessions) | the mandate never authorised it | ● none | **nothing** — a line in prose | — |
| Do not `create.schedule.tenant` (create something that outlives the session, on the platform (a routine, a scheduled trigger, a new session)) | the mandate refuses it | ◐ setting | the per-action approval prompt: "By default, each action Claude takes on your behalf requires your explicit approval. On Team and Enterprise plans, owners decide whether members can allow certain actions to run without asking each time." | you — moves without you: **yes** |

Who holds a barrier is the question this table used to leave out. A condition enforced by something the organisation holds is a different undertaking from one enforced by something a supplier can withdraw in a release, and the licence is being signed over both.

## Void when

- the grant version changes — a product release, a setting, a connector enabled or removed
- the mandate changes — the deployer authorises more or less
- the vocabulary version changes — a primitive is added, split or renamed
- a barrier moves — a setting becomes a boundary, or a boundary is removed

When any of those happens the deployment changed, not this document. Rebuild, re-read the delta, and re-issue.

## Signature

Signed by the accountable owner named above on —, for the interval stated. The same person owns the review when it ends.

---

_This describes the deployment shape as at this date. If the risk changed, the deployment changed — not this document._ 
No score, rating, level or traffic light appears in this vault or in its data, and none will. The behaviour policy describes; it does not judge. 
Generated by `scripts/site/build-abp-vault.mjs` from `data/grant.json`, `data/mandate.json` and the pinned vocabulary; `data/mandate.json` is the only file a person writes. Licence: the published template is CC BY 4.0; a paid copy carries a commercial licence to the buyer. See LICENCE.md.

